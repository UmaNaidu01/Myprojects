package com.example.aiapp;

public class appconflict {
}
