package com.example.aiapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MavenApplicationTests {

    @Test
    void contextLoads() {
    }

}
